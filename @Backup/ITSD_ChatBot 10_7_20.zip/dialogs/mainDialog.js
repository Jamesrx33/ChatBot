
const { MessageFactory, InputHints, CardFactory, ShowTypingMiddleware} = require('botbuilder');
const { LuisRecognizer } = require('botbuilder-ai');
const { ComponentDialog, DialogSet, DialogTurnStatus, TextPrompt, ConfirmPrompt, WaterfallDialog } = require('botbuilder-dialogs');
const axios = require("axios");
const postChatIncident = require( "./POSTChatIncident");
const postNewIncident = require( "./POSTNewIncident");
const postNewChatIncident = require("./POSTNewChatIncident")
const updateIncident = require("./UpdateIncident");
const closeIncident = require("./UpdateIncident");
const getGroupData = require("./getGroupData");

const CONFIRM_PROMPT = 'confirmPrompt';



  //Array Available Agent for use in loadBalancer return value
  var AvailableAgent = {};


  //Initiate the IncidentDetails object for communicating with Dialogs
  const IncidentDetails = {};
  IncidentDetails.id = '';
  IncidentDetails.assignee = '';
  IncidentDetails.requester = '';
  IncidentDetails.title = '';
  IncidentDetails.details = '';
  IncidentDetails.type = '';



/*

****************Deprecated Graph caller info*************************

const graphCaller = require('./getGraphData');

//Includes for obtaining MS Graph Token
const APP_ID = 'dac4ebbe-dfde-4487-80ce-0850f72034e3'
const APP_SECERET = 'v-UNOCCe5WkRwm3~e7x_XVL8-FTnCdD-I5'
const TOKEN_ENDPOINT ='https://login.microsoftonline.com/3ea4ee53-5e07-4a30-bd0d-e464769a4f4f/oauth2/v2.0/token';
const MS_GRAPH_SCOPE = 'https://graph.microsoft.com/.default';
const qs = require('qs');

var graphAccessToken = {};

*/

const MAIN_WATERFALL_DIALOG = 'mainWaterfallDialog';

class MainDialog extends ComponentDialog {
    constructor(luisRecognizer, createIncidentDialog, createChatIncidentDialog, reassignIncidentDialog, closeIncidentDialog) {
        super('MainDialog');

        if (!luisRecognizer) throw new Error('[MainDialog]: Missing parameter \'luisRecognizer\' is required');
        this.luisRecognizer = luisRecognizer;

        if (!createIncidentDialog) throw new Error('[MainDialog]: Missing parameter \'createIncidentDialog\' is required');

        if (!createChatIncidentDialog) throw new Error('[MainDialog]: Missing parameter \'createIncidentDialog\' is required');

        if (!reassignIncidentDialog) throw new Error('[MainDialog]: Missing parameter \'reassignIncidentDialog\' is required');

        if (!closeIncidentDialog) throw new Error('[MainDialog]: Missing parameter \'closeIncidentDialog\' is required');

        // Define the main dialog and its related components.



        this.addDialog(new TextPrompt('TextPrompt'))
            .addDialog(new ConfirmPrompt(CONFIRM_PROMPT))
            .addDialog(createIncidentDialog)
            .addDialog(createChatIncidentDialog)
            .addDialog(reassignIncidentDialog)
            .addDialog(closeIncidentDialog)
            .addDialog(new WaterfallDialog(MAIN_WATERFALL_DIALOG, [
                this.introStep.bind(this),
                this.actStep.bind(this),
                this.selectStep.bind(this),
                this.finalStep.bind(this)
            ]));

        this.initialDialogId = MAIN_WATERFALL_DIALOG;
    }

    /**
     * The run method handles the incoming activity (in the form of a TurnContext) and passes it through the dialog system.
     * If no dialog is active, it will start the default dialog.
     * @param {*} turnContext
     * @param {*} accessor
     */
    async run(turnContext, accessor) {
        const dialogSet = new DialogSet(accessor);
        dialogSet.add(this);

        const dialogContext = await dialogSet.createContext(turnContext);
        const results = await dialogContext.continueDialog();
        if (results.status === DialogTurnStatus.empty) {
            await dialogContext.beginDialog(this.id);
        }
    }

    /**
     * First step in the waterfall dialog. Prompts the user for a command.
     * Currently, this will send a "What can we help you with today" prompt after the welcome card.
     */
    async introStep(stepContext) {
        if (!this.luisRecognizer.isConfigured) {
            const messageText = 'NOTE: LUIS is not configured. To enable all capabilities, add `LuisAppId`, `LuisAPIKey` and `LuisAPIHostName` to the .env file.';
            await stepContext.context.sendActivity(messageText, null, InputHints.IgnoringInput);
            return await stepContext.next();
        }



        
        const messageText = stepContext.options.restartMsg ? stepContext.options.restartMsg : `Saying "Chat with IT" will get you connected to the next available representative.`;
        const promptMessage = MessageFactory.text(messageText, messageText, InputHints.ExpectingInput);
        return await stepContext.prompt('TextPrompt', { prompt: promptMessage });
    }

    /**
     * Second step in the waterfall.  This will initiate the LUIS AI and get user intent.
     */
    async actStep(stepContext) {


        // Call LUIS and Intent. (Note the TurnContext has the response to the prompt)
        const luisResult = await this.luisRecognizer.executeLuisQuery(stepContext.context);

        //Error testing for LUIS intent
        //const luis_MessageText = 'LUIS Intent was ' + LuisRecognizer.topIntent(luisResult) + '. Hopefully thats right';
        //await stepContext.context.sendActivity(luis_MessageText, luis_MessageText, InputHints.IgnoringInput);

        if(LuisRecognizer.topIntent(luisResult) == 'Chat'){
          const Chat_messageText = 'I have identified that you want to Chat with a member of ITService. Finding the next available representative...';
          await stepContext.context.sendActivity(Chat_messageText, Chat_messageText, InputHints.IgnoringInput);
        }


        //Switch to catch the top Intent of LUIS -- on an identified intent, Dialog will route to the correct action. 
        //Defaults to "I didnt unserstand that" if intent not identified
    
        switch (LuisRecognizer.topIntent(luisResult)) {
        case 'Cancel' : {
            //This will end session on a Cancel intent

            const cancelMessageText = 'I have identified that you want to ' + LuisRecognizer.topIntent(luisResult) + '. Closing dialog. If you wish to continue, type another phrase.';
            await stepContext.context.sendActivity(cancelMessageText, cancelMessageText, InputHints.IgnoringInput);
            
            return await stepContext.cancelAllDialogs();

        } 
        case 'Reassign_Ticket' : {
        //This will start a dialog that requests information for the incident on a Reassign Incident intent

        //Now that LUIS has identified the Reassign Incident intent - need to send a call to an async function that returns user input
        IncidentDetails.type = "Reassign";
        const reassign_messageText = 'I have identified that you want to Reassign a ticket.';
        await stepContext.context.sendActivity(reassign_messageText, reassign_messageText, InputHints.IgnoringInput);

       // console.log(stepContext.context);


        //What i need: begin dialog for user, await return of info from user, then make a POST API call
        return await stepContext.beginDialog('reassignIncidentDialog', IncidentDetails);
      } 
      case 'Create_Ticket' : {
        //This will start a dialog that requests information for the incident on a Create Ticket intent

        //Now that LUIS has identified the Create Ticket intent - need to send a call to an async function that returns user input
        IncidentDetails.type = "Create";

        const create_messageText = 'I have identified that you want to Create a New Incident.';
        await stepContext.context.sendActivity(create_messageText, create_messageText, InputHints.IgnoringInput);

       // console.log(stepContext.context);


        //What i need: begin dialog for user, await return of info from user, then make a POST API call
        return await stepContext.beginDialog('createIncidentDialog', IncidentDetails);
    } 
    case 'Close_Ticket' : {
        //This will start a dialog that requests information for the incident on a Close Incident intent

        //Now that LUIS has identified the Close Incident intent - need to send a call to an async function that returns user input
        IncidentDetails.type = "Close";
        const close_messageText = 'I have identified that you want to Close an Incident.';
        await stepContext.context.sendActivity(close_messageText, close_messageText, InputHints.IgnoringInput);

       // console.log(stepContext.context);


        //What i need: begin dialog for user, await return of info from user, then make a POST API call
        return await stepContext.beginDialog('closeIncidentDialog', IncidentDetails);

  } 
        case 'Chat': {
           
  // get system local time
  var d = new Date();
  var m = d.getMinutes();
  var h = d.getHours();

 // h = h+5;   //<< Time adjustment for local testing

 
  
  var currentTime = h+"."+m;

  if(currentTime < 12.00)
  {

    const Chat2_messageText = 'I apologize, but it is currently beyond regular business hours for ITService. Please try again Mon-Fri from 5am-5pm PDT.';
    await stepContext.context.sendActivity(Chat2_messageText, Chat2_messageText, InputHints.IgnoringInput);
    break;

  }else{

            //Declare Agent object.
           //This will be used to store agent information 
           //Agent informaton will be sent to the loadBalancer method to find the next available Agent based on Chats received in last 24 hours

            var Agent = {};
            Agent.name = [];
            Agent.email = [];
            Agent.ticketCount = [];
            Agent.id = [];
            Agent.image = [];
            Agent.recentUpdate = [new Date()];




//    **This is code for enabling the API**
        const GroupPromise = await getGroupData.getGroupData();

        const processing = 'Processing...';
        await stepContext.context.sendActivity(processing, processing, InputHints.IgnoringInput);

        const GroupData = await this.obtainAssigneeFromPromise(GroupPromise);


        const RecentIncidentPromise = await getGroupData.getRecentIncident(GroupData);

        const RecentIncident = await this.obtainIncidentFromPromise(RecentIncidentPromise, Agent, GroupData);

        const found = 'Agent Found...';
        await stepContext.context.sendActivity(found, found, InputHints.IgnoringInput);



        Agent.recentUpdate = RecentIncident.recentUpdate;
        
        for(var i = 0; i<Agent.recentUpdate.length; i++){
          var day = new String();
          day = Agent.recentUpdate[i]
          day = day[8] + day[9];
          console.log("THIS IS THE DAY " + day);
          Agent.recentUpdate[i] = day;
        }


        const activeMembers = await getGroupData.getActiveMembers(GroupData, Agent);
 



           //Start loadBalancer method to get next available agent and POST incident in their queue -- returns agent data

          AvailableAgent = await this.loadBalancer(activeMembers);




//Construct adaptive card based on user values (The above will be changed later to reflect live SD personnel)

if(AvailableAgent.name == 'Michael Mooney'){
    AvailableAgent.region = 'Newport Beach';
}

console.log(AvailableAgent.ticketCount);


var ticketCountHolder = AvailableAgent.ticketCount;


const card = CardFactory.adaptiveCard({
    "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
  "type": "AdaptiveCard",
  "version": "1.0",
  "body": [
    {
      "type": "Container",
      "items": [
        {
          "type": "ColumnSet",
          "columns": [
            {
              "type": "Column",
              "width": "auto",
              "items": [
                {
                  "size": "small",
                  "style": "person",
                  "type": "Image",
                  "url": `${AvailableAgent.image}`
                }
              ]
            },
            {
              "type": "Column",
              "width": "stretch",
              "items": [
                {
                  "type": "TextBlock",
                  "weight": "bolder",
                  "size": "extralarge",
                  "text":  `${AvailableAgent.name}`,
                  "wrap": true
                },
              ]
            }
          ]
        }
      ]
    },
    {
      "type": "Container",
      "items": [
        {
          "type": "TextBlock",
          "text": `${AvailableAgent.name}` + " has been assigned to you.\n",
          "wrap": true
        },
        {
          "type": "FactSet",
          "facts": [
            {
              "title": "Title:",
              "value": "Service Desk Analyst"
            },
            {
              "title": "Region:",
              "value": `${AvailableAgent.region}`
            },
            {
              "title": "Email:",
              "value": `${AvailableAgent.email}`
            },
            {
              "title": "Chats Today:",
              "value": `${ticketCountHolder}`
            }
          ]
        }
      ]
    }
  ],
});
const message = MessageFactory.attachment(card);
await stepContext.context.sendActivity(message);


const messageText = `Do you need immediate assistance?`;
const msg = MessageFactory.text(messageText, messageText, InputHints.ExpectingInput);

// Offer a YES/NO prompt.
return await stepContext.prompt(CONFIRM_PROMPT, { prompt: msg });
}
        }
        default: {
            // Catch all for unhandled intents
            const didntUnderstandMessageText = `Sorry, I didn't get that. Please try asking in a different way (intent was ${ LuisRecognizer.topIntent(luisResult) })`;
            await stepContext.context.sendActivity(didntUnderstandMessageText, didntUnderstandMessageText, InputHints.IgnoringInput);
        }

  
      }

           
            return await stepContext.next();
 
    }


//Load balancer method for Chat intent

    async loadBalancer(ActivePersonnel){

      //Declare URL and Headers for GET ChatData API call
      const BASE_URL = "https://dprconstruction.samanage.com/incidents?report_id=9288733&applied=true&assigned_to%5B%5D=1784743&assigned_to%5B%5D=3518814&assigned_to%5B%5D=3574680&assigned_to%5B%5D=4498568&assigned_to%5B%5D=5763508&created%5B%5D=1&121985%5B%5D=Chat&sort_by=number&sort_order=DESC&per_page=100&page=1"
      const Headers = {
          headers: {
          "X-Samanage-Authorization": "Bearer U1dTRC1pZG1BUElAZHByLmNvbQ==:eyJhbGciOiJIUzUxMiJ9.eyJ1c2VyX2lkIjo1Njk2Mzc5LCJnZW5lcmF0ZWRfYXQiOiIyMDIwLTA0LTI3IDE5OjE2OjAzIn0.Ndvz5eaeD1AFhl25kMh-8-buw0BuMUm1EhS9OWBYyNrCrM9KEnXaiAIH1z3Rx_LZHrlLrHC0IoBsZl6wc7qFMg",
          "Accept": "application/json"
         }
      };


      //GET Chat incident data of Service Desk Team

      var ChatData = await axios.get(BASE_URL, Headers)
      .then(response => {

        //Call obtainDataFromPromise to extract the GET data
        var retVal = this.obtainDataFromPromise(response);

        //Return the resultant data and put into ChatData variable
        return retVal;
        }, (error) => {
        console.log(error); //Error Checking on Axios call
      });

        //Initialize ticketCount field for Active Personnel Object
        try {
          for(var i=0;i < ActivePersonnel.name.length;i++){
            ActivePersonnel.ticketCount[i] = 0;
          }
        } catch (error) {
          console.log(error); //Error checking on ticketCount initialization
        }
    
        //For every incident found in ChatData, check if the assignee name equals an ActivePersonnel name, then append 1 to ticketCount for that personnel if found
        for(var i=0;i < ChatData.length;i++){
          for(var index=0;index < ActivePersonnel.name.length;index++){
            if(ActivePersonnel.name[index] == ChatData[i].assignee.name)
            {
            ActivePersonnel.ticketCount[index] = ActivePersonnel.ticketCount[index] + 1;
            console.log("Appended 1 chat incident for " + ActivePersonnel.name[index])
            }
          }
        }


              
        //Declare placeholder for ActivePersonnel Chat Info
        const placeholder = {};
        placeholder.name = '';
        placeholder.email = '';
        placeholder.region = 'Austin';
        placeholder.image = ActivePersonnel.image[0];
        placeholder.name = ActivePersonnel.name[0];
        placeholder.email = ActivePersonnel.email[0];
        placeholder.ticketCount = ActivePersonnel.ticketCount[0];


       //Identify which active personnel has the least number of incidents with the "Chat" origin in the last 24 hours.
       //Then place the agents information into placeholder for use in calls and return.

      for(var i=0;i < ActivePersonnel.name.length;i++){
        if(ActivePersonnel.ticketCount[i] < placeholder.ticketCount)
        {
            placeholder.name = ActivePersonnel.name[i];
            placeholder.email = ActivePersonnel.email[i];
            placeholder.image = ActivePersonnel.image[i];
            placeholder.ticketCount = ActivePersonnel.ticketCount[i];

            console.log (placeholder.name + "Added to placeholder")
        }
      }
        
  
  
      return placeholder;
  }

 
  async obtainAssigneeFromPromise (promise){
    var assignee = [];
    for(var i=0; i<promise.data.length; i++){
      assignee[i]=promise.data[i].assignee
    console.log(promise.data[i].assignee.name + " Placed in asignee variable")
    }
    return assignee;
  }

  async obtainIncidentFromPromise (promise, agent, groupData){
    var pass = [0,0,0,0,0];

    for(var i=0; i<promise.data.length; i++){
      if(promise.data[i].assignee.name == groupData[0].name && pass[0] != 1){

        agent.recentUpdate[0]=promise.data[i].created_at
        console.log(promise.data[i].created_at + " into " + groupData[0].name + " array variable.")
        pass[0] = 1;

      }else if(promise.data[i].assignee.name == groupData[1].name && pass[1] != 1){

        agent.recentUpdate[1]=promise.data[i].created_at
        console.log(promise.data[i].created_at + " into " + groupData[1].name + " array variable.")
        pass[1] = 1;

      }else if(promise.data[i].assignee.name == groupData[2].name && pass[2] != 1){

        agent.recentUpdate[2]=promise.data[i].created_at
        console.log(promise.data[i].created_at + " into " + groupData[2].name + " array variable.")
        pass[2] = 1;

      }else if(promise.data[i].assignee.name == groupData[3].name && pass[3] != 1){

        agent.recentUpdate[3]=promise.data[i].created_at
        console.log(promise.data[i].created_at + " into " + groupData[3].name + " array variable.")
        pass[3] = 1;

      }else if(promise.data[i].assignee.name == groupData[4].name && pass[4] != 1){

        agent.recentUpdate[4]=promise.data[i].created_at
        console.log(promise.data[i].created_at + " into " + groupData[4].name + " array variable.")
        pass[4] = 1;

      }

      console.log("Processing next ticket..." + i)
    }
    return agent;
  }


  //For use in obtaining data from Axios GET responses

  async obtainDataFromPromise (promise){
    return promise.data;
  }


async selectStep(stepContext){

  if(stepContext.result == true){

    //POST Chat incident to the identified personnel for tracking of assigned Chat incidents
    try {
     const returncode = await postChatIncident.postChatIncident(AvailableAgent.email);

     //Deploy return code to ensure successful POST request
     // console.log(returncode);
   } catch (error) {
       console.log(error); //Error checking on postChatIncident function call (POST AXIOS function)
   }
 

  const ChatCard = CardFactory.adaptiveCard({
    "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
    "type": "AdaptiveCard",
    "version": "1.0",
    "body": [
      {
        "type": "TextBlock",
        "weight": "bolder",
        "size": "small",
        "text": `Click the link below to start your chat with ${AvailableAgent.name} `
      }
    ],
    "actions": [
      {
        "type": "Action.OpenUrl",
        "title": "Start a Chat",
        "url": "https://teams.microsoft.com/l/chat/0/0?users=ITService@dpr.com," + AvailableAgent.email + "&topicName=New%20ITService%20Chat%20From%20Bot&message=Hello%2C%20I%20need%20assistance%20please"
      }
    ]
  });


const Chatmessage = MessageFactory.attachment(ChatCard);
await stepContext.context.sendActivity(Chatmessage);



  }else if(stepContext.result == false){

    IncidentDetails.type = "ChatIncident";


    //What i need: begin dialog for user, await return of info from user, then make a POST API call
    return await stepContext.beginDialog('createChatIncidentDialog', IncidentDetails);
  }

  return await stepContext.next();

}


    
    async finalStep(stepContext) {

      //If stepContext finds data (Incident creations processes) -- Post incident

      if(stepContext.result){
      const result = stepContext.result;
      if(result.type == 'Create'){
      try {
        const returncode = postNewIncident.postNewIncident(result.assignee, result.title, result.details);
        if(returncode)
        {
          const msg = result.title + ` incident was successfully created.`;
          await stepContext.context.sendActivity(msg, msg, InputHints.IgnoringInput);
        }else{
          const msg = result.title + ` incident was not successfully created -- please try again.`;
          await stepContext.context.sendActivity(msg, msg, InputHints.IgnoringInput);
        };

        //Log return code for testing
        //console.log(returncode);

      } catch (error) {
          console.log(error);   //Error checking on postNewIncident function (AXIOS POST function)
      }
    }else if(result.type == 'ChatIncident'){
      try {
        const returncode = postNewChatIncident.postChatNewIncident(result.requester, AvailableAgent.email, result.details);
        if(returncode)
        {
          const msg = `Incident was successfully created and assigned`;
          await stepContext.context.sendActivity(msg, msg, InputHints.IgnoringInput);
        }else{
          const msg = `Incident was not successfully created -- please try again.`;
          await stepContext.context.sendActivity(msg, msg, InputHints.IgnoringInput);
        };

        //Log return code for testing
        //console.log(returncode);
      
      } catch (error) {
        console.log(error);   //Error checking on postNewIncident function (AXIOS POST function)
    }
    }else if(result.type == 'Reassign'){
      try {
        
        const returncode = updateIncident.reassignIncident(result.assignee, result.id);
        if(returncode)
        {
          const msg = "Incident was successfully assigned";
          await stepContext.context.sendActivity(msg, msg, InputHints.IgnoringInput);
        }else{
          const msg = result.assignee + ` incident was not successfully updated -- no 200 response`;
          await stepContext.context.sendActivity(msg, msg, InputHints.IgnoringInput);
        };

        //Log return code for testing
        //console.log(returncode);

      } catch (error) {
          console.log(error);  //Error checking on reassignIncident function (AXIOS PUT function)
      }
    }else if(result.type == 'Close'){
      try {
        
        const returncode = closeIncident.closeIncident(result.id);
        if(returncode)
        {
          const msg = "Incident " + result.id + " was successfully closed.";
          await stepContext.context.sendActivity(msg, msg, InputHints.IgnoringInput);
        }else{
          const msg = result.assignee + ` incident was not successfully updated -- no 200 response`;
          await stepContext.context.sendActivity(msg, msg, InputHints.IgnoringInput);
        };

        //Log return code for testing
        //console.log(returncode);

      } catch (error) {
          console.log(error); //Error checking on closeIncident function (AXIOS PUT function)
      }
    }else{
      const msg = "No action type found. Please try again.";
      await stepContext.context.sendActivity(msg, msg, InputHints.IgnoringInput);

    }
  }

    //Always replace current dialog with "What else can i do for you" at waterfall end
      return await stepContext.replaceDialog(this.initialDialogId, { restartMsg: 'What else can I do for you?' });
  
    }
}

module.exports.MainDialog = MainDialog;
