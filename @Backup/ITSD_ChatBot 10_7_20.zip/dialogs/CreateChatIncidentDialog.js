const { TimexProperty } = require('@microsoft/recognizers-text-data-types-timex-expression');
const { InputHints, MessageFactory } = require('botbuilder');
const { ConfirmPrompt, TextPrompt, WaterfallDialog } = require('botbuilder-dialogs');
const { CancelAndHelpDialog } = require('./cancelAndHelpDialog');
const { DateResolverDialog } = require('./dateResolverDialog');

const CONFIRM_PROMPT = 'confirmPrompt';
const DATE_RESOLVER_DIALOG = 'dateResolverDialog';
const TEXT_PROMPT = 'textPrompt';
const WATERFALL_DIALOG = 'waterfallDialog';


class CreateChatIncidentDialog extends CancelAndHelpDialog {
    constructor(id) {
        super(id || 'createChatIncidentDialog');

        this.addDialog(new TextPrompt(TEXT_PROMPT))
            .addDialog(new ConfirmPrompt(CONFIRM_PROMPT))
            .addDialog(new DateResolverDialog(DATE_RESOLVER_DIALOG))
            .addDialog(new WaterfallDialog(WATERFALL_DIALOG, [
                this.requesterStep.bind(this),
                this.detailsStep.bind(this),
                this.confirmStep.bind(this),
                this.endStep.bind(this)
            ]));

        this.initialDialogId = WATERFALL_DIALOG;
    }

    /**
     * Who should the incident be assigned to?
     */
    async requesterStep(stepContext) {
        const incidentDetails = stepContext.options;

        if (incidentDetails.requester == '') {
            const messageText = 'Please enter your email address.';
            const msg = MessageFactory.text(messageText, messageText, InputHints.ExpectingInput);
            return await stepContext.prompt(TEXT_PROMPT, { prompt: msg });
        }
        return await stepContext.next(incidentDetails.requester);
    }

    /**
     * Obtain the details of the incident. 
     */

    async detailsStep(stepContext) {
        const incidentDetails = stepContext.options;

        // Capture the results of the previous step
        incidentDetails.requester = stepContext.result;

        if (incidentDetails.details == '') {
            const messageText = 'Please describe the issue or request.';
            const msg = MessageFactory.text(messageText, messageText, InputHints.ExpectingInput);
            return await stepContext.prompt(TEXT_PROMPT, { prompt: msg });
        }
        return await stepContext.next(incidentDetails.details);
    }

    /**
     * Confirm the information the user has provided.
     */
    async confirmStep(stepContext) {
        const incidentDetails = stepContext.options;

        // Capture the results of the previous step
        incidentDetails.details = stepContext.result;
        
        const msg1 = `Please confirm, I have the requester as: ${ incidentDetails.requester } `;
        await stepContext.context.sendActivity(msg1, msg1, InputHints.IgnoringInput);
        const msg2 = `With the following details: \n ${ incidentDetails.details } `;
        await stepContext.context.sendActivity(msg2, msg2, InputHints.IgnoringInput);
        const messageText = `Is this correct?\n WARNING, If the your email is not written correctly, the ticket will not be created.`;
        const msg = MessageFactory.text(messageText, messageText, InputHints.ExpectingInput);

        // Offer a YES/NO prompt.
        return await stepContext.prompt(CONFIRM_PROMPT, { prompt: msg });
    }


    /**
     * Complete the interaction and end the dialog.
     */
    async endStep(stepContext) {
        if (stepContext.result === true) {
            const incidentDetails = stepContext.options;
            return await stepContext.endDialog(incidentDetails);
        }
        return await stepContext.endDialog();
    }

    isAmbiguous(timex) {
        const timexPropery = new TimexProperty(timex);
        return !timexPropery.types.has('definite');
    }
}

module.exports.CreateChatIncidentDialog = CreateChatIncidentDialog;
